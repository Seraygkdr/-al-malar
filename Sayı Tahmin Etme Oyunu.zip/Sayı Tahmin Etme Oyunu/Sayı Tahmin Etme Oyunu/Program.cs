﻿using System;
using System.Linq;

class Program
{
    static int[] RandomSayiUret()
    {
        try
        {
            Random random = new Random();
            int[] digits = new int[4];
            bool[] used = new bool[10];

            digits[0] = random.Next(1, 10);
            used[digits[0]] = true;

            for (int i = 1; i < 4; i++)
            {
                int digit;
                do
                {
                    digit = random.Next(0, 10);
                } while (used[digit]);
                digits[i] = digit;
                used[digit] = true;
            }
            return digits;
        }
        catch
        {
            Console.WriteLine($"Sayı üretilirken hata oluştu.");
            return new int[] { 1, 2, 3, 4 };
        }
    }

    static int tahminDegerlendir(int[] pcNumber, int[] kullaniciTahmin)
    {
        try
        {
            int result = 0;
            for (int i = 0; i < 4; i++)
            {
                if (pcNumber.Contains(kullaniciTahmin[i]))
                {
                    result += (pcNumber[i] == kullaniciTahmin[i]) ? 1 : -1;
                }
            }
            return result;
        }
        catch
        {
            Console.WriteLine($"Tahmin değerlendirilirken hata.");
            return 0;
        }
    }

    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Bilgisayar 4 basamaklı, rakamları birbirinden farklı ve ilk basamağı 0 olmayan bir sayı tuttu.");
            Console.WriteLine("Lütfen tahmininizi ilk basamağı 0 olmuyacak şekilde 4 basamaklı, rakamları farklı giriniz:");
            Console.WriteLine("Kurallar: Sayı ve yeri doğruysa +1, sayı doğru ama yeri yanlışsa -1.");

            int[] pcNumber = RandomSayiUret();
            bool isCorrect = false;
            int attempts = 0;

            while (!isCorrect)
            {
                try
                {
                    Console.Write("Tahmininiz:");
                    string input = Console.ReadLine();

                    if (input.Length != 4 || !int.TryParse(input, out _) || input[0] == '0' || input.Distinct().Count() != 4)
                    {
                        Console.WriteLine("Geçersiz giriş!");
                        continue;
                    }
                    attempts++;

                    int[] kullanıcıTahmin = new int[4];
                    for (int i = 0; i < 4; i++)
                    {
                        kullanıcıTahmin[i] = int.Parse(input[i].ToString());
                    }
                    int result = tahminDegerlendir(pcNumber, kullanıcıTahmin);

                    if (result == 4)
                    {
                        isCorrect = true;
                        Console.WriteLine($"Tebrikler! {attempts} denemede doğru sayıyı buldunuz: {string.Join("", pcNumber)}");
                    }
                    else
                    {
                        Console.WriteLine($"Sonuç: {result}");
                    }
                }
                catch
                {
                    Console.WriteLine("Hata: Geçersiz sayı formatı. Lütfen sadece rakam girin.");
                    Console.WriteLine($"Beklenmeyen bir hata oluştu.");
                }
            }
        }
        catch
        {
            Console.WriteLine($"Kritik hata.");
            Console.WriteLine("Oyun Bitiyor!!!");
        }
    }
}