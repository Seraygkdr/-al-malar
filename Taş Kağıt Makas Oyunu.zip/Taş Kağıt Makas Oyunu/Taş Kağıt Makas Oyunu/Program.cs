﻿int kazanan;
int kaybeden;
string kullanici = "";
string devamDegiskeni = "E";
Random pc = new Random(); // Random nesnesi DÖNGÜ DIŞINDA tek sefer oluşturulur

do
{
    kazanan = 0;
    kaybeden = 0;

    for (int el = 0; el < 10 && kazanan < 3 && kaybeden < 3; el++)
    {
        string gecerliGirdi = "";
        bool gecerliMi = false;

        while (!gecerliMi) // Geçerli giriş yapılana kadar tekrar sor
        {
            Console.WriteLine("Taş, kağıt ve makas seçeneklerinden birini girin (tas/kagit/makas):");
            kullanici = Console.ReadLine().ToLower();
            if (kullanici == "tas" || kullanici == "kagit" || kullanici == "makas")
                gecerliMi = true;
            else
                Console.WriteLine("Hatalı giriş! Lütfen 'tas', 'kagit' veya 'makas' yazın.");
        }

        string[] secenek = { "tas", "kagit", "makas" };
        int pcSecimIndex = pc.Next(3); 
        string pcSecim = secenek[pcSecimIndex];
        Console.WriteLine($"Pc secimi = {pcSecim}");

        // Kazanma/kaybetme kontrolleri
        if (kullanici == "tas" && pcSecim == "kagit")
            kaybeden++;
        else if (kullanici == "kagit" && pcSecim == "tas")
            kazanan++;
        else if (kullanici == "makas" && pcSecim == "tas")
            kaybeden++;
        else if (kullanici == "tas" && pcSecim == "makas")
            kazanan++;
        else if (kullanici == "makas" && pcSecim == "kagit")
            kazanan++;
        else if (kullanici == "kagit" && pcSecim == "makas")
            kaybeden++;
        else
            Console.WriteLine("Berabere!");

        Console.WriteLine($"Skor: Sen {kazanan} - {kaybeden} Pc");
    }

    if (kazanan > kaybeden)
        Console.WriteLine("Tebrikler oyunu kazandınız!");
    else
        Console.WriteLine("Maalesef oyunu kaybettiniz.");

    Console.WriteLine("Devam edelim mi? (E/H): ");
    devamDegiskeni = Console.ReadLine().ToUpper();
} while (devamDegiskeni == "E");