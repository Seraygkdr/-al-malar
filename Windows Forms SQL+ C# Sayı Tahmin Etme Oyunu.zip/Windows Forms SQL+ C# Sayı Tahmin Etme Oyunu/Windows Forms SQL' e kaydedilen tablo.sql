create database Github
use Github
create table OyunLoglar(
SB_id int primary key identity(1,1),
SB_oyuncuAdi nvarchar(50),
SB_hedefSayi int,
SB_toplamHamle int,
SB_gecenSure int,
SB_tarih datetime )