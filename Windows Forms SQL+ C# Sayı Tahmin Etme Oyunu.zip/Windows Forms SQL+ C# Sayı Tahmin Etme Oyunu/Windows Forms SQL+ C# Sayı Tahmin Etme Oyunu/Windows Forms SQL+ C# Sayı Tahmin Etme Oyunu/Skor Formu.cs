﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Forms_SQL__C__Sayı_Tahmin_Etme_Oyunu
{
    public partial class Skor_Formu : Form
    {
        string connectionString = "Server=.\\SQLEXPRESS;Database=Github;Trusted_Connection=True;";
        public Skor_Formu()
        {
            InitializeComponent();
        }

        private void Skor_Formu_Load(object sender, EventArgs e)
        {
            VerileriYukle();
            VerileriHesapla();
        }
        private void VerileriYukle()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {

                    string query = "SELECT SB_oyuncuAdi, SB_hedefSayi, SB_toplamHamle, SB_gecenSure, SB_tarih FROM OyunLoglar ORDER BY SB_toplamHamle ASC";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);//Veritabanından çekilen verileri, bağlantıyı sürekli açık tutmadan bellekte bir tablo halinde tutmamızı sağlar


                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veriler yüklenirken hata oluştu: " + ex.Message);
            }
        }
        private void VerileriHesapla()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // Ortalama Hamle Sayısını hesaplayan fonksiyon
                    string query = "SELECT AVG(CAST( SB_toplamHamle AS FLOAT)) FROM OyunLoglar";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != DBNull.Value && result != null)
                    {
                        double ortalama = Convert.ToDouble(result);

                        // Progressbarda max 50 hamle
                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 50;

                        // Değer ProgressBar sınırları içindeyse ata
                        if (ortalama <= 50)
                            progressBar1.Value = (int)ortalama;
                        else
                            progressBar1.Value = 50;

                        // Ortalamayı yazdır
                        label1.Text = $"Ortalama Hamle Sayısı: {ortalama:F2}";
                    }
                    else
                    {
                        label1.Text = "Henüz kayıtlı oyun yok.";
                        progressBar1.Value = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("İstatistikler hesaplanırken hata oluştu: " + ex.Message);
            }
        }

    }
}
    