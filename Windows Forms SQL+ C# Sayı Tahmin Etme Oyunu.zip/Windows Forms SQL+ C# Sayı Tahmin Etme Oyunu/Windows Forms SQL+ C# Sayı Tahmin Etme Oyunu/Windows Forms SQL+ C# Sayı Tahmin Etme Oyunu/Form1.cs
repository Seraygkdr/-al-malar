﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Windows_Forms_SQL__C__Sayı_Tahmin_Etme_Oyunu
{
    public partial class Form1 : Form
    {
        string hedefSayi = "";
        int id = 0;
        int hamleSayisi = 0;
        int gecenSure = 0;


        string connectionString = "Server=.\\SQLEXPRESS;Database=Github;Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("KURALLAR: Eğer rakam ve yeri doğru ise +1 Eğer rakam ve yeri yanlış ise -1 şeklinde ilerler");
            YeniOyunBaslat();
        }

        private void YeniOyunBaslat()
        {
            hedefSayi = RandomSayi();
            hamleSayisi = 0;
            gecenSure = 0;
            listBox1.Items.Clear();
            timer1.Start();
        }
        private string RandomSayi()
        {
            Random rnd = new Random();
            List<int> rakamlar = new List<int>();
            while (rakamlar.Count < 4)
            {
                int yeniRakam = rnd.Next(0, 10);


                if (rakamlar.Count == 0 && yeniRakam == 0) continue;

                if (!rakamlar.Contains(yeniRakam))
                    rakamlar.Add(yeniRakam);
            }
            return string.Join("", rakamlar);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tahmin = textBox2.Text;


            if (tahmin.Length != 4 || !int.TryParse(tahmin, out _))//ilk olarak textboxaa yazılan uzunluğu kontrol ediyor sonra da yazılan ifadeler tamamiyle metin mi ona bakıyor 
            {
                MessageBox.Show("Lütfen 4 basamaklı, rakamlardan oluşan bir sayı giriniz!");
                return;
            }

            hamleSayisi++;
            int arti = 0;
            int eksi = 0;


            for (int i = 0; i < 4; i++)
            {
                if (tahmin[i] == hedefSayi[i])
                    arti++; // Rakam doğru ve yeri doğru 
                else if (hedefSayi.Contains(tahmin[i].ToString()))
                    eksi++; // Rakam doğru fakat yeri yanlış 
            }

            listBox1.Items.Add($"{hamleSayisi}. Tahmin: {tahmin} | Sonuç: +{arti}, -{eksi}"); // listboxa eklenen ıtemlerı gösteriyor 

            if (arti == 4)
            {
                timer1.Stop();
                MessageBox.Show($"Tebrikler! {hamleSayisi} hamlede buldunuz.");
                LogKaydet();
            }

            textBox2.Clear();
            textBox2.Focus();
        }

        private void LogKaydet()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // Oyuncu Adı, Hedef Sayı, Hamle, Süre ve Tarih bilgileri 
                    string query = "INSERT INTO OyunLoglar (SB_oyuncuAdi,SB_hedefSayi,SB_toplamHamle,SB_gecenSure,SB_tarih) " +
                                   "VALUES (@ad, @hedef, @hamle, @sure, @tarih)";//sql deki yaptığım tabloya ulşamaya yarar.

                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@ad", textBox1.Text);
                    cmd.Parameters.AddWithValue("@hedef", hedefSayi);
                    cmd.Parameters.AddWithValue("@hamle", hamleSayisi);
                    cmd.Parameters.AddWithValue("@sure", gecenSure);
                    cmd.Parameters.AddWithValue("@tarih", DateTime.Now);

                    conn.Open();
                    cmd.ExecuteNonQuery();//sorgu döndürmez sadece veritabanında değişiklik yapar ve etkilenen satır sayısını bildirir.
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            gecenSure++;
            label3.Text = "Süre: " + gecenSure + " sn";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LogKaydet();

            Skor_Formu skor = new Skor_Formu();
            skor.ShowDialog();//Skor tablosunu açıyoruz
        }
    }
    
}
