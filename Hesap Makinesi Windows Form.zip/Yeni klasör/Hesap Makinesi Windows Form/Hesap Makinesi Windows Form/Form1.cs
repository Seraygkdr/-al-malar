﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hesap_Makinesi_Windows_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       // private void Form1_Load(object sender, EventArgs e)
        //{

        //}

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            label1.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                textBox1.Text = textBox1.Text + "0";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }
        double sayı1;
        double sayı2;
        string ope;

        private void button11_Click(object sender, EventArgs e)
        {
            sayı1 = Convert.ToDouble(textBox1.Text);
            ope = "+";
            label1.Text = textBox1.Text + ope;
            textBox1.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            sayı1 = Convert.ToDouble(textBox1.Text);
            ope="-";
            label1.Text = textBox1.Text + ope;
            textBox1.Text = "";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            sayı1 = Convert.ToDouble(textBox1.Text);
            ope = "/";
            label1.Text = textBox1.Text+ ope;
            textBox1.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            sayı1 = Convert.ToDouble(textBox1.Text);
            ope = "*";
            label1.Text= textBox1.Text + ope;
            textBox1.Text = "";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox1.Text))  return; 
            sayı2 = Convert.ToDouble(textBox1.Text);

            double result =0;

            if(ope == "+")
            {
                result = sayı1 + sayı2;
            }
            else if(ope == "-")
            {
                result = sayı1 - sayı2;
            }
            else if (ope == "/")
            {
                if (sayı2 != 0)
                    result = sayı1 / sayı2;
                else
                    MessageBox.Show("Bir sayı sıfıra bölünemez!");
            }
            else if (ope == "*")
            {
                result = sayı1 * sayı2;
            }

            label1.Text = sayı1.ToString() + " " + ope + " " + sayı2.ToString() + "=";

            textBox1.Text =result.ToString();
        }
    }
}
